import random
import main

class Individuo:
    def __init__(self, caminho, escolhas_personagens):
        self.caminho = caminho
        self.escolhas_personagens = escolhas_personagens
        self.fitness = float('inf')
        self.tempo_total = 0
        self.personagens_vivos = {p: 5 for p in main.characters}
        self.desafios_enfrentados = set()
        
    def exibir_detalhes_jornada(self):
        print("\nDetalhes da jornada:")
        for detalhe in self.detalhes_jornada:
            print(f"De {detalhe['de']} para {detalhe['para']}: {detalhe['tempo_viagem']:.2f} minutos")
            if detalhe['personagens']:  # Só mostra detalhes do evento se houver personagens
                print(f"Evento {detalhe['para']} - Personagens utilizados: {detalhe['personagens']}")
                print(f"Tempo para completar o evento: {detalhe['tempo_evento']:.2f} minutos")
                print(f"Poder total: {detalhe['poder_total']:.2f}")
            print("-" * 50)

    def calcular_fitness(self, mapa, start, end):
        self.tempo_total = 0
        self.desafios_enfrentados.clear()
        personagens_disponiveis = {p: 5 for p in main.characters}
        posicao_atual = start
        detalhes_jornada = []  # Lista para armazenar os detalhes da jornada

        # Passa por todos os eventos na ordem correta
        for i, evento in enumerate(self.caminho):
            pos_evento = main.find_position(evento, mapa)
            
            # Calcula tempo até o evento
            _, tempo_ate_evento = main.busca(set(), mapa, posicao_atual, pos_evento)
            if tempo_ate_evento == float('inf'):
                return float('inf')  # Se não encontrar um caminho, solução inválida

            self.tempo_total += tempo_ate_evento
            
            # Verifica personagens disponíveis para o evento
            personagens_escolhidos = self.escolhas_personagens.get(evento, [])
            personagens_ativos = [p for p in personagens_escolhidos if personagens_disponiveis[p] > 0]
            
            if not personagens_ativos:
                return float('inf')  # Nenhum personagem disponível, solução inválida
            
            # Calcula poder total e tempo do evento
            poder_total = sum(main.characters[p][0] for p in personagens_ativos)
            tempo_evento = main.events_with_cost[evento] / poder_total
            
            # Armazena os detalhes do evento
            origem = 'I' if i == 0 else main.melhor_ordem[i-1]
            detalhes_jornada.append({
                'de': origem,
                'para': evento,
                'tempo_viagem': tempo_ate_evento,
                'personagens': personagens_ativos,
                'tempo_evento': tempo_evento,
                'poder_total': poder_total
            })

            # Atualiza estado dos personagens e tempo total
            for p in personagens_ativos:
                personagens_disponiveis[p] -= 1
            
            self.tempo_total += tempo_evento
            self.desafios_enfrentados.add(evento)
            posicao_atual = pos_evento

        # Caminho final até J
        _, tempo_ate_final = main.busca(set(), mapa, posicao_atual, end)
        if tempo_ate_final == float('inf'):
            return float('inf')

        self.tempo_total += tempo_ate_final
        detalhes_jornada.append({
            'de': main.melhor_ordem[-1],
            'para': 'J',
            'tempo_viagem': tempo_ate_final,
            'personagens': [],
            'tempo_evento': 0,
            'poder_total': 0
        })

        self.detalhes_jornada = detalhes_jornada

        personagens_vivos_count = sum(1 for v in personagens_disponiveis.values() if v > 0)
        desafios_nao_enfrentados = len(main.melhor_ordem) - len(self.desafios_enfrentados)

        self.fitness = self.tempo_total + (desafios_nao_enfrentados * 1000) - (personagens_vivos_count * 100)
        
        self.personagens_vivos = personagens_disponiveis.copy()
        return self.fitness
    
    def exibir_status(self):
        print(f"Tempo total: {self.tempo_total}")
        print("Status dos personagens:")
        for p, energia in self.personagens_vivos.items():
            status = "Vivo" if energia > 0 else "Fora"
            print(f"  {p}: {energia} usos restantes ({status})")
        print(f"Desafios enfrentados: {', '.join(sorted(self.desafios_enfrentados))}")

def criar_individuo():
    caminho = main.melhor_ordem[:]          
    personagens = list(main.characters)     
    usos = {p: 5 for p in personagens}

    escolhas = {}
    idx = 0                                 
    for e in caminho:
        
        while usos[personagens[idx]] == 0:
            idx = (idx + 1) % len(personagens)

        escolhido = personagens[idx]
        escolhas[e] = [escolhido]          
        usos[escolhido] -= 1
        idx = (idx + 1) % len(personagens)

    return Individuo(caminho, escolhas)




def algoritmo_genetico(mapa, start, end, tamanho_populacao, geracoes, taxa_mutacao):
    populacao = [criar_individuo() for _ in range(tamanho_populacao)]
    melhor_solucao = None
    melhor_fitness = float('inf')

    for geracao in range(geracoes):
        for individuo in populacao:
            fitness_atual = individuo.calcular_fitness(mapa, start, end)
            
            if fitness_atual < melhor_fitness:
                melhor_fitness = fitness_atual
                melhor_solucao = individuo

        populacao.sort(key=lambda x: x.fitness)
        melhores = populacao[:tamanho_populacao // 2]
        
        nova_populacao = melhores.copy()
        
        while len(nova_populacao) < tamanho_populacao:
            pai, mae = random.sample(melhores, 2)
            filho1, filho2 = crossover(pai, mae)
            mutacao(filho1, taxa_mutacao)
            mutacao(filho2, taxa_mutacao)
            nova_populacao.extend([filho1, filho2])
        
        populacao = nova_populacao
        
        if (geracao + 1) % 10 == 0:
            print(f"Geração {geracao + 1}: Melhor Fitness = {melhor_fitness:.2f}")

    print("\nMelhor solução encontrada:")
    melhor_solucao.exibir_status()
    melhor_solucao.exibir_detalhes_jornada()
    
    return melhor_solucao

def mutacao(individuo, taxa_mutacao):
    for evento in individuo.escolhas_personagens:
        if random.random() < taxa_mutacao:
            # Pode adicionar ou remover personagens
            num_personagens = random.randint(1, len(main.characters))
            individuo.escolhas_personagens[evento] = random.sample(list(main.characters.keys()), num_personagens)

def crossover(pai, mae):
    ponto_corte = random.randint(1, min(len(pai.caminho), len(mae.caminho)) - 1)
    filho1_caminho = pai.caminho[:ponto_corte] + mae.caminho[ponto_corte:]
    filho2_caminho = mae.caminho[:ponto_corte] + pai.caminho[ponto_corte:]

    filho1_escolhas = pai.escolhas_personagens.copy()
    filho2_escolhas = mae.escolhas_personagens.copy()

    for evento in main.events_with_cost:
        if random.random() < 0.5:
            filho1_escolhas[evento], filho2_escolhas[evento] = filho2_escolhas[evento], filho1_escolhas[evento]

    return Individuo(filho1_caminho, filho1_escolhas), Individuo(filho2_caminho, filho2_escolhas)

def mutacao(individuo, mapa, taxa_mutacao):
    # Mutação do caminho, escolhendo vizinhos aleatórios para coordenadas
    if random.random() < taxa_mutacao:
        ponto = random.randint(0, len(individuo.caminho) - 1)
        vizinhos = main.get_neighborhood(mapa, individuo.caminho[ponto])
        if vizinhos:
            individuo.caminho[ponto] = random.choice(vizinhos)

    # Mutação nas escolhas de personagens para cada evento
    for evento in individuo.escolhas_personagens:
        if random.random() < taxa_mutacao:
            personagens_vivos = [p for p in main.characters if individuo.personagens_vivos[p] > 0]
            if personagens_vivos:
                individuo.escolhas_personagens[evento] = random.sample(personagens_vivos, random.randint(1, len(personagens_vivos)))
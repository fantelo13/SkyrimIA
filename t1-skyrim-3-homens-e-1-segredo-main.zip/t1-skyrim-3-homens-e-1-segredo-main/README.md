# SkyrimIA
Repositório que inclui o primeiro trabalho relacionado ao conteúdo da matéria de Inteligência Artificial (INF1771) da PUC-Rio

Custo com personagens = 6206.72
Tempo total: 6806.72

LINK : https://youtu.be/VS_glcFUuZI?si=yZ0xVr1RHBhJUwSg 
